import React from 'react';
import { Layout } from '@/components/Layout';
import { Card } from '@/components/Card';
import { useMockData } from '@/hooks/useMockData';
import { 
  FileText, 
  Download, 
  Filter, 
  CheckCircle, 
  Clock, 
  XCircle,
  Calendar,
  BarChart3
} from 'lucide-react';
import { cn } from '@/lib/utils';

export function Relatorios() {
  const { reports, loading } = useMockData();

  if (loading) {
    return (
      <Layout 
        title="Monitoramento Ambiental" 
        subtitle="Relatório em tempo real - Fevereiro 2024"
      >
        <div className="flex items-center justify-center h-64">
          <div className="text-gray-500">Carregando relatórios...</div>
        </div>
      </Layout>
    );
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'processing':
        return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'error':
        return <XCircle className="h-4 w-4 text-red-500" />;
      default:
        return <Clock className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed':
        return 'Concluído';
      case 'processing':
        return 'Processando';
      case 'error':
        return 'Erro';
      default:
        return 'Desconhecido';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'processing':
        return 'bg-yellow-100 text-yellow-800';
      case 'error':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR');
  };

  return (
    <Layout 
      title="Monitoramento Ambiental" 
      subtitle="Relatório em tempo real - Fevereiro 2024"
    >
      <div className="space-y-6">
        {/* Filtros */}
        <Card>
          <div className="flex flex-col sm:flex-row sm:items-center gap-4">
            <div className="flex flex-col sm:flex-row sm:items-center gap-4 flex-1">
              <div className="flex items-center gap-2">
                <label className="text-sm font-medium text-gray-700">
                  Período:
                </label>
                <select className="border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white">
                  <option>Últimos 7 dias</option>
                  <option>Últimos 30 dias</option>
                  <option>Últimos 90 dias</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <label className="text-sm font-medium text-gray-700">
                  Poluente:
                </label>
                <select className="border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white">
                  <option>Todos</option>
                  <option>CO</option>
                  <option>NO₂</option>
                  <option>SO₂</option>
                  <option>PM2.5</option>
                </select>
              </div>

              <div className="flex items-center gap-2">
                <label className="text-sm font-medium text-gray-700">
                  Unidade:
                </label>
                <select className="border border-gray-300 rounded-lg px-3 py-2 text-sm bg-white">
                  <option>Todas</option>
                  <option>Unidade 1</option>
                  <option>Unidade 2</option>
                  <option>Unidade 3</option>
                </select>
              </div>
            </div>

            <button className="bg-blue-500 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-blue-600">
              <Filter className="h-4 w-4" />
              Aplicar Filtros
            </button>
          </div>
        </Card>

        {/* Header da lista */}
        <Card>
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center gap-4">
              <h2 className="text-lg font-medium text-gray-800">
                Dados de Medição
              </h2>
              <span className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-sm">
                {reports.length} registros
              </span>
            </div>

            <div className="flex gap-2">
              <button className="border border-gray-300 rounded-lg px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                <FileText className="h-4 w-4 text-red-500" />
                PDF
              </button>
              <button className="border border-gray-300 rounded-lg px-3 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50 flex items-center gap-2">
                <BarChart3 className="h-4 w-4 text-green-500" />
                Excel
              </button>
            </div>
          </div>
        </Card>

        {/* Lista de relatórios */}
        <div className="space-y-4">
          {reports.map((report) => (
            <Card key={report.id}>
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                    <FileText className="h-5 w-5 text-blue-600" />
                  </div>
                  
                  <div className="flex-1">
                    <h3 className="text-sm font-medium text-gray-900">
                      {report.title}
                    </h3>
                    <div className="flex items-center gap-4 mt-1 text-xs text-gray-500">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-3 w-3" />
                        {formatDate(report.date)}
                      </div>
                      <div className="flex items-center gap-1">
                        {getStatusIcon(report.status)}
                        <span className={cn(
                          "px-2 py-1 rounded-full text-xs font-medium",
                          getStatusColor(report.status)
                        )}>
                          {getStatusText(report.status)}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {report.status === 'completed' && (
                    <button className="bg-blue-500 text-white px-3 py-2 rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-blue-600">
                      <Download className="h-4 w-4" />
                      Download
                    </button>
                  )}
                  
                  {report.status === 'processing' && (
                    <div className="text-sm text-yellow-600 font-medium">
                      Processando...
                    </div>
                  )}
                  
                  {report.status === 'error' && (
                    <button className="bg-red-500 text-white px-3 py-2 rounded-lg text-sm font-medium hover:bg-red-600">
                      Tentar Novamente
                    </button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}

