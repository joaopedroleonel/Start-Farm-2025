import React, { useEffect } from 'react';
import { Layout } from '@/components/Layout';
import { MetricCard } from '@/components/Card';
import { Chart } from '@/components/Chart';
import { useMockData } from '@/hooks/useMockData';
import { Wind, Cloud, Droplets, Gauge } from 'lucide-react';

export function Dashboard() {
  const { 
    sensors, 
    emissionTrends, 
    weeklyEmissions,
    monthlyComparison,
    pollutants, 
    hourlyEmissions,
    loading, 
    updateSensorData 
  } = useMockData();

  // Simular atualizações em tempo real
  useEffect(() => {
    const interval = setInterval(() => {
      updateSensorData();
    }, 10000); // Atualizar a cada 10 segundos

    return () => clearInterval(interval);
  }, [updateSensorData]);

  if (loading) {
    return (
      <Layout 
        title="Monitoramento Ambiental" 
        subtitle="Relatório em tempo real - Fevereiro 2024"
      >
        <div className="flex items-center justify-center h-64">
          <div className="text-gray-500">Carregando dados...</div>
        </div>
      </Layout>
    );
  }

  const getIconForSensor = (sensorId: string) => {
    switch (sensorId) {
      case 'co':
        return <Wind className="h-4 w-4 text-blue-600" />;
      case 'no2':
        return <Cloud className="h-4 w-4 text-yellow-600" />;
      case 'so2':
        return <Droplets className="h-4 w-4 text-green-600" />;
      case 'pm25':
        return <Gauge className="h-4 w-4 text-purple-600" />;
      default:
        return <Wind className="h-4 w-4 text-blue-600" />;
    }
  };

  const getIconBgColor = (sensorId: string) => {
    switch (sensorId) {
      case 'co':
        return 'bg-blue-100 dark:bg-blue-900/50';
      case 'no2':
        return 'bg-yellow-100 dark:bg-yellow-900/50';
      case 'so2':
        return 'bg-green-100 dark:bg-green-900/50';
      case 'pm25':
        return 'bg-purple-100 dark:bg-purple-900/50';
      default:
        return 'bg-blue-100 dark:bg-blue-900/50';
    }
  };

  return (
    <Layout 
      title="Monitoramento Ambiental" 
      subtitle="Relatório em tempo real - Fevereiro 2024"
    >
      <div className="space-y-8">
        {/* Título da seção */}
        <div className="space-y-2">
          <h2 className="text-xl lg:text-2xl font-semibold text-gray-900 font-poppins">
            Monitoramento de Emissões Atmosféricas
          </h2>
          <p className="text-sm lg:text-base text-gray-600 font-poppins">
            Dados da última semana - Atualizado em tempo real
          </p>
        </div>

        {/* Cards de métricas */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          {sensors.map((sensor) => (
            <MetricCard
              key={sensor.id}
              title={sensor.name}
              value={sensor.value}
              unit={sensor.unit}
              icon={getIconForSensor(sensor.id)}
              status={sensor.status}
              stats={{
                max: sensor.max,
                min: sensor.min,
                avg: sensor.avg
              }}
              iconBgColor={getIconBgColor(sensor.id)}
            />
          ))}
        </div>

        {/* Gráficos principais */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Chart
            title="Tendência de Emissões (24h)"
            data={emissionTrends}
            type="line"
            height={300}
            dataKey="value"
            xAxisKey="name"
            colors={['#3B82F6']}
          />
          
          <Chart
            title="Distribuição de Poluentes"
            data={pollutants}
            type="pie"
            height={300}
            dataKey="value"
            colors={['#3B82F6', '#EF4444', '#10B981', '#F59E0B']}
          />
        </div>

        {/* Gráficos secundários */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Chart
            title="Emissões Semanais"
            data={weeklyEmissions}
            type="bar"
            height={300}
            dataKey="value"
            xAxisKey="name"
            colors={['#10B981']}
          />
          
          <Chart
            title="Comparação Mensal"
            data={monthlyComparison}
            type="bar"
            height={300}
            dataKey="atual"
            xAxisKey="name"
            colors={['#3B82F6', '#EF4444']}
          />
        </div>

        {/* Gráfico de área - Histórico detalhado */}
        <div className="grid grid-cols-1">
          <Chart
            title="Histórico Detalhado de Emissões (24h)"
            data={hourlyEmissions}
            type="area"
            height={400}
            dataKey="value"
            xAxisKey="name"
            colors={['#8B5CF6']}
          />
        </div>
      </div>
    </Layout>
  );
}

