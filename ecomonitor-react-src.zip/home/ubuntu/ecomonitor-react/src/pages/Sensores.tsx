import React from 'react';
import { Layout } from '@/components/Layout';
import { Card, MetricCard } from '@/components/Card';
import { useMockData } from '@/hooks/useMockData';
import { 
  Cpu, 
  Download, 
  Wifi, 
  Battery, 
  MapPin, 
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle
} from 'lucide-react';
import { cn } from '@/lib/utils';

export function Sensores() {
  const { devices, deviceStats, loading } = useMockData();

  if (loading) {
    return (
      <Layout 
        title="Monitoramento Ambiental" 
        subtitle="Relatório em tempo real - Fevereiro 2024"
      >
        <div className="flex items-center justify-center h-64">
          <div className="text-gray-500">Carregando sensores...</div>
        </div>
      </Layout>
    );
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online':
        return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'offline':
        return <XCircle className="h-4 w-4 text-red-500" />;
      case 'maintenance':
        return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      default:
        return <XCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'online':
        return 'Online';
      case 'offline':
        return 'Offline';
      case 'maintenance':
        return 'Manutenção';
      default:
        return 'Desconhecido';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
        return 'bg-green-100 text-green-800';
      case 'offline':
        return 'bg-red-100 text-red-800';
      case 'maintenance':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatLastSeen = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Agora mesmo';
    if (diffInMinutes < 60) return `${diffInMinutes} min atrás`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h atrás`;
    return `${Math.floor(diffInMinutes / 1440)} dias atrás`;
  };

  const getBatteryColor = (level?: number) => {
    if (!level) return 'text-gray-400';
    if (level > 50) return 'text-green-500';
    if (level > 20) return 'text-yellow-500';
    return 'text-red-500';
  };

  const getSignalColor = (strength?: number) => {
    if (!strength) return 'text-gray-400';
    if (strength > 70) return 'text-green-500';
    if (strength > 40) return 'text-yellow-500';
    return 'text-red-500';
  };

  return (
    <Layout 
      title="Monitoramento Ambiental" 
      subtitle="Relatório em tempo real - Fevereiro 2024"
    >
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div>
            <h2 className="text-xl lg:text-2xl font-bold text-gray-900 mb-2">
              Gestão de Dispositivos IoT
            </h2>
            <p className="text-gray-600">
              Monitoramento em tempo real de sensores de chaminés industriais
            </p>
          </div>
          <button className="w-12 h-12 lg:w-auto lg:h-auto lg:px-4 lg:py-2 bg-white rounded-lg border border-gray-300 flex items-center justify-center lg:justify-start gap-2 hover:bg-gray-50">
            <Download className="h-4 w-4 text-gray-700" />
            <span className="hidden lg:inline text-sm">Exportar</span>
          </button>
        </div>

        {/* Estatísticas */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          <MetricCard
            title="Total Dispositivos"
            value={deviceStats.total}
            icon={<Cpu className="h-4 w-4 text-blue-600" />}
            iconBgColor="bg-blue-100"
          />
          <MetricCard
            title="Online"
            value={deviceStats.online}
            icon={<CheckCircle className="h-4 w-4 text-green-600" />}
            iconBgColor="bg-green-100"
          />
          <MetricCard
            title="Offline"
            value={deviceStats.offline}
            icon={<XCircle className="h-4 w-4 text-red-600" />}
            iconBgColor="bg-red-100"
          />
          <MetricCard
            title="Manutenção"
            value={deviceStats.maintenance}
            icon={<AlertTriangle className="h-4 w-4 text-yellow-600" />}
            iconBgColor="bg-yellow-100"
          />
        </div>

        {/* Lista de dispositivos */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-gray-900">
              Dispositivos Conectados
            </h3>
            <div className="text-sm text-gray-500">
              {devices.length} dispositivos
            </div>
          </div>

          {devices.map((device) => (
            <Card key={device.id}>
              <div className="flex flex-col lg:flex-row lg:items-center gap-4">
                <div className="flex items-start gap-4 flex-1">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <Cpu className="h-6 w-6 text-blue-600" />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-sm font-medium text-gray-900">
                        {device.name}
                      </h4>
                      <span className={cn(
                        "px-2 py-1 rounded-full text-xs font-medium",
                        getStatusColor(device.status)
                      )}>
                        {getStatusText(device.status)}
                      </span>
                    </div>
                    
                    <div className="flex items-center gap-4 text-xs text-gray-500">
                      <div className="flex items-center gap-1">
                        <MapPin className="h-3 w-3" />
                        {device.location}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {formatLastSeen(device.lastSeen)}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-6">
                  {device.batteryLevel !== undefined && (
                    <div className="flex items-center gap-2">
                      <Battery className={cn("h-4 w-4", getBatteryColor(device.batteryLevel))} />
                      <span className="text-sm text-gray-600">
                        {device.batteryLevel}%
                      </span>
                    </div>
                  )}
                  
                  {device.signalStrength !== undefined && (
                    <div className="flex items-center gap-2">
                      <Wifi className={cn("h-4 w-4", getSignalColor(device.signalStrength))} />
                      <span className="text-sm text-gray-600">
                        {device.signalStrength}%
                      </span>
                    </div>
                  )}
                  
                  <div className="flex items-center gap-1">
                    {getStatusIcon(device.status)}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
}

