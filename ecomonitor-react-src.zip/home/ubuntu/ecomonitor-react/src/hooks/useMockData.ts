import { useState, useEffect } from 'react';
import { 
  sensorData, 
  chartData, 
  emissionTrendData, 
  weeklyEmissionData,
  monthlyComparisonData,
  pollutantDistribution, 
  hourlyEmissionData,
  deviceStatusData,
  reportData, 
  deviceData 
} from '@/data/mockData';
import { SensorData, ChartData, ReportData, DeviceData } from '@/types';

export function useMockData() {
  const [sensors, setSensors] = useState<SensorData[]>([]);
  const [charts, setCharts] = useState<ChartData[]>([]);
  const [emissionTrends, setEmissionTrends] = useState<ChartData[]>([]);
  const [weeklyEmissions, setWeeklyEmissions] = useState<ChartData[]>([]);
  const [monthlyComparison, setMonthlyComparison] = useState<any[]>([]);
  const [pollutants, setPollutants] = useState<any[]>([]);
  const [hourlyEmissions, setHourlyEmissions] = useState<ChartData[]>([]);
  const [deviceStatus, setDeviceStatus] = useState<any[]>([]);
  const [reports, setReports] = useState<ReportData[]>([]);
  const [devices, setDevices] = useState<DeviceData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simular carregamento de dados
    const loadData = async () => {
      setLoading(true);
      
      // Simular delay de API
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setSensors(sensorData);
      setCharts(chartData);
      setEmissionTrends(emissionTrendData);
      setWeeklyEmissions(weeklyEmissionData);
      setMonthlyComparison(monthlyComparisonData);
      setPollutants(pollutantDistribution);
      setHourlyEmissions(hourlyEmissionData);
      setDeviceStatus(deviceStatusData);
      setReports(reportData);
      setDevices(deviceData);
      
      setLoading(false);
    };

    loadData();
  }, []);

  // Função para atualizar dados de sensores (simular tempo real)
  const updateSensorData = () => {
    setSensors(prevSensors => 
      prevSensors.map(sensor => ({
        ...sensor,
        value: Number((sensor.value + (Math.random() - 0.5) * 2).toFixed(1)),
        lastUpdate: new Date().toISOString()
      }))
    );
  };

  // Função para filtrar relatórios por status
  const getReportsByStatus = (status: ReportData['status']) => {
    return reports.filter(report => report.status === status);
  };

  // Função para filtrar dispositivos por status
  const getDevicesByStatus = (status: DeviceData['status']) => {
    return devices.filter(device => device.status === status);
  };

  // Estatísticas dos dispositivos
  const deviceStats = {
    total: devices.length,
    online: devices.filter(d => d.status === 'online').length,
    offline: devices.filter(d => d.status === 'offline').length,
    maintenance: devices.filter(d => d.status === 'maintenance').length
  };

  return {
    sensors,
    charts,
    emissionTrends,
    weeklyEmissions,
    monthlyComparison,
    pollutants,
    hourlyEmissions,
    deviceStatus,
    reports,
    devices,
    loading,
    updateSensorData,
    getReportsByStatus,
    getDevicesByStatus,
    deviceStats
  };
}

